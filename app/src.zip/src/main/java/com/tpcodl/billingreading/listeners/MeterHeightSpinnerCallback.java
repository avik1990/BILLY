package com.tpcodl.billingreading.listeners;

public interface MeterHeightSpinnerCallback {
    public void meterHeightSpinnerSelectedItem(int position, String value, String sortedValue);

}
