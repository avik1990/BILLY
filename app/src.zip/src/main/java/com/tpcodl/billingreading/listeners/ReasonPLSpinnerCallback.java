package com.tpcodl.billingreading.listeners;

public interface ReasonPLSpinnerCallback {
    public void reasonPLSpinnerSelectedItem(int position, String value, String sortedValue);

}
