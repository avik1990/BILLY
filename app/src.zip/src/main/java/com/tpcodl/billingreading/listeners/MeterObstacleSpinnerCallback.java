package com.tpcodl.billingreading.listeners;

public interface MeterObstacleSpinnerCallback {
    public void meterObstacleSpinnerSelectedItem(int position, String value, String sortedValue);

}
