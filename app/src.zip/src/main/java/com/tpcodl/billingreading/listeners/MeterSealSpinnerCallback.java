package com.tpcodl.billingreading.listeners;

public interface MeterSealSpinnerCallback {
    public void meterSealSpinnerSelectedItem(int position, String value,String sortedName);

}
