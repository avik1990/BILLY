package com.tpcodl.billingreading.listeners;

public interface ReasonOfCdSpinnerCallback {
    public void reasonOfCdSpinnerSelectedItem(int position, String value,String sortedName);

}
