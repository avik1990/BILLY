package com.tpcodl.billingreading.requestModel;

public class ValidationRequestModel {
}
