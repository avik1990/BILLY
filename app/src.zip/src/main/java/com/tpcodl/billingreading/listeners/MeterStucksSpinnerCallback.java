package com.tpcodl.billingreading.listeners;

public interface MeterStucksSpinnerCallback {
    public void meterStuckSpinnerSelectedItem(int position, String value,String sortedName);

}
