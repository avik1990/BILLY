package com.tpcodl.billingreading.listeners;

public interface ReasonDCSpinnerCallback {
    public void reasonDCSSpinnerSelectedItem(int position, String value, String sortedValue);

}
