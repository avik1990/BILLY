package com.tpcodl.billingreading.listeners;

public interface PaperPasteSpinnerCallback {
    public void paperPasteSpinnerSelectedItem(int position, String value,String sortedName);

}
