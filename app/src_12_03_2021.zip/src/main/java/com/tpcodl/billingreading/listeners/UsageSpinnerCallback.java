package com.tpcodl.billingreading.listeners;

public interface UsageSpinnerCallback {

    public void usageSpinnerSelectedItem(int position,String value,String sortedValue);
}
