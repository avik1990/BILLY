package com.tpcodl.billingreading.listeners;

public interface ReasonOfENSpinnerCallback {
    public void reasonOfENSpinnerSelectedItem(int position, String value,String sortedName);

}
