package com.tpcodl.billingreading.listeners;

public interface SupplyStatusSpinnerCallback {

    public void supplyStatusSpinnerSelectedItem(int position, String value,String sortedName);
}
