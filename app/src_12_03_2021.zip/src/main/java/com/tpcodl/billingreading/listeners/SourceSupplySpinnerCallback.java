package com.tpcodl.billingreading.listeners;

public interface SourceSupplySpinnerCallback {

    public void sourceSupplySpinnerSelectedItem(int position, String value,String sortedName);
}
