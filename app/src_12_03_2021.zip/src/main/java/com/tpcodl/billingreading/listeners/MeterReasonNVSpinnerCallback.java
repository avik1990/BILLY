package com.tpcodl.billingreading.listeners;

public interface MeterReasonNVSpinnerCallback {
    public void meterReasonNVSpinnerSelectedItem(int position, String value, String sortedValue);

}
