package com.tpcodl.billingreading.listeners;

public interface MeterTypeSpinnerCallback {

    public void meterTypeSpinnerSelectedItem(int position, String value,String sortedName);
}
