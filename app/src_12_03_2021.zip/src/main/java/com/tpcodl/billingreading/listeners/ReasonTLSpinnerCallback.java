package com.tpcodl.billingreading.listeners;

public interface ReasonTLSpinnerCallback {
    public void reasonTLSpinnerSelectedItem(int position, String value, String sortedValue);

}
