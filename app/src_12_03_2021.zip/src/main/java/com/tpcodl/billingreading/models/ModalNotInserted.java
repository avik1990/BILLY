package com.tpcodl.billingreading.models;

public class ModalNotInserted {
    String installationNo="";
    boolean isInserted;

    public String getInstallationNo() {
        return installationNo;
    }

    public void setInstallationNo(String installationNo) {
        this.installationNo = installationNo;
    }

    public boolean isInserted() {
        return isInserted;
    }

    public void setInserted(boolean inserted) {
        isInserted = inserted;
    }
}
