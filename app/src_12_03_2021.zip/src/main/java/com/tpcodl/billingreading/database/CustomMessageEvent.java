package com.tpcodl.billingreading.database;

public class CustomMessageEvent {
    public String customMessage;

    public String getCustomMessage() {
        return customMessage;
    }

    public void setCustomMessage(String customMessage) {
        this.customMessage = customMessage;
    }
}
