package com.tpcodl.billingreading.listeners;

import android.net.Uri;

public interface ImageCallback {
    void onSuccess(Uri mImageUYri, int resultCode);
}
